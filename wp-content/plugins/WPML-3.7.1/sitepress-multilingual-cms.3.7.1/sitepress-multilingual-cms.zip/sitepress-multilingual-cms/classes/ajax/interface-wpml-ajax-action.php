<?php

interface IWPML_AJAX_Action {
	public function run();
}