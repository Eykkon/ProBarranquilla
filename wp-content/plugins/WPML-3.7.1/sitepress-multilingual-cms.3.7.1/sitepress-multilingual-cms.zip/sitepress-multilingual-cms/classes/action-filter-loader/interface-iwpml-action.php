<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_Action {
	public function add_hooks();
}
